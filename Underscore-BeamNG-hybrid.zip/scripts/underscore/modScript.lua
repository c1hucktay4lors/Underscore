-- Underscore-BeamNG mod entry point (Game Engine Lua)
-- Loaded automatically by BeamNG's mod system when this mod is enabled.

local ok, err = pcall(function()
    -- Load the GE-side extension that owns UDP and player vehicle tracking
    extensions.load("underscoreOut")
    -- Keep it alive across level changes and vehicle respawns
    setExtensionUnloadMode("underscoreOut", "manual")
end)

if not ok then
    log("E", "Underscore-BeamNG", ("Failed to load underscoreOut: %s"):format(tostring(err)))
else
    log("I", "Underscore-BeamNG", "modScript loaded successfully")
end
