# Underscore-BeamNG Mod

Broadcasts the active player's BeamNG.drive ignition state over UDP so external software (e.g., audio ducking) can distinguish key positions.

## Protocol

- **Destination:** `127.0.0.1:4445`
- **Packet format:** Exactly one byte per packet
  - `0` = ignition off
  - `1` = accessory (radio on, engine off)
  - `2` = ignition on / engine running
  - `3` = starter/cranking
- **Behavior:** State changes sent immediately; heartbeat every ~1 second

## Installation

1. Place `Underscore-BeamNG.zip` in your BeamNG mods folder:
   - Windows: `%USERPROFILE%\AppData\LocalLow\BeamNG.drive\mods\`
   - Linux (native): `~/.local/share/BeamNG.drive/mods/` or Steam userdata path
2. In-game, open **Options → Mods**, enable "Underscore-BeamNG"
3. Restart the game

## Verification

Open F10 console and check for:
```
I GELua.Underscore-BeamNG modScript loaded successfully
I underscoreOut onExtensionLoaded
I underscoreOut ignition broadcast -> 127.0.0.1:4445
```

After spawning a vehicle:
```
I underscoreOut Queued underscoreIgnition into player vehicle <id>
I underscoreIgnition loaded in vehicle <name>
```

Test with a UDP listener (e.g., `nc -ul 4445` or the included diagnostic tool) and cycle your key.

## Architecture

BeamNG has separate Lua virtual machines:

- **Game Engine Lua (GELUA):** Runs at `lua/ge/extensions/`. Owns networking, UI, world management.
- **Vehicle Lua (VLUA):** Runs at `lua/vehicle/extensions/` inside each vehicle's simulation context. Owns electrics data.

This mod uses two extensions respecting that boundary:

1. **GE extension** (`lua/ge/extensions/underscoreOut.lua`)
   - Opens UDP socket to 127.0.0.1:4445
   - Tracks current player vehicle via `be:getPlayerVehicle(0)`
   - Loads VLUA extension into that vehicle via VM bridge
   - Receives ignition values from VLUA and broadcasts externally

2. **VLUA extension** (`lua/vehicle/extensions/underscoreIgnition.lua`)
   - Reads `electrics.values.ignitionLevel` directly (only accessible in VLUA)
   - Sends values back to GE via `obj:queueGameEngineLua(...)`

Data flow: Vehicle electrics → VLUA extension → VM bridge → GE extension → UDP → localhost:4445

## Notes

- Requires LuaSocket (bundled with BeamNG.drive 0.39+)
- Only tracks the active player vehicle; no per-frame iteration over all vehicles
- Non-fatal failure handling: if UDP socket fails to initialize, errors are logged but don't crash the game
