-- Underscore-BeamNG - Game Engine side (GELUA)
--
-- Architecture note: BeamNG has separate Lua VMs. This extension runs in
-- Game Engine Lua and owns the external UDP protocol. It does NOT read
-- vehicle electrics directly — that data lives in Vehicle Lua (VLUA).
--
-- Responsibilities:
--   * Own the UDP socket to 127.0.0.1:4445.
--   * Detect the current player vehicle via be:getPlayerVehicle(0).
--   * Load the vehicle-side underscoreIgnition extension into that vehicle.
--   * Receive ignitionLevel values from Vehicle Lua via VM bridge.
--   * Broadcast one byte per packet (ignition level 0–3) with ~1 Hz heartbeat.
--
-- Wire protocol:
--   0 = ignition off
--   1 = accessory only
--   2 = ignition on / engine running
--   3 = starter/cranking

local M = {}

local HOST, PORT = "127.0.0.1", 4445
local HEARTBEAT_INTERVAL = 1.0    -- external UDP heartbeat period (seconds)

local udp = nil                   -- LuaSocket UDP handle
local running = false             -- extension active flag
local currentVehicleId = -1       -- last vehicle ID we loaded the VLUA ext into
local lastLevel = -1              -- last ignition level broadcast externally
local elapsed = 0                 -- total uptime for heartbeat timing


-- ── Broadcast a level via UDP ────────────────────────────────────────────────
local function broadcast(level)
    if not udp then return false end

    level = math.max(0, math.min(3, math.floor(level)))

    local ok, err = pcall(function()
        udp:sendto(string.char(level), HOST, PORT)
    end)

    if not ok then
        log("E", "underscoreOut", ("UDP send failed: %s"):format(tostring(err)))
        return false
    end

    return true
end


-- ── Called from Vehicle Lua via obj:queueGameEngineLua(...) ──────────────────
local function receiveIgnition(level)
    if not running then return end
    if type(level) ~= "number" then return end

    -- Round to nearest int (BeamNG may send fractional values during transitions)
    level = math.floor(level + 0.5)
    if level < 0 or level > 3 then return end

    -- Send immediately on change, otherwise rely on GE heartbeat for liveness
    if level ~= lastLevel then
        log("I", "underscoreOut", ("ignitionLevel=%d"):format(level))
    end

    broadcast(level)
    lastLevel = level
end

-- Expose for VLUA→GE bridge calls (called from queueGameEngineLua string)
M.receiveIgnition = receiveIgnition


-- ── Load vehicle extension into current player vehicle (once per vehicle) ────
local function ensureVehicleExtension()
    if not be or type(be.getPlayerVehicle) ~= "function" then return end

    local vehicle = be:getPlayerVehicle(0)
    if not vehicle then
        -- No player vehicle yet (main menu, etc.) — reset tracking
        currentVehicleId = -1
        return
    end

    local id = vehicle:getID()
    if id == currentVehicleId then return end  -- already loaded for this vehicle

    currentVehicleId = id

    -- Cross from GELUA into this vehicle's VLUA to load our extension.
    -- Vehicle extensions auto-load, but explicit load ensures it's active immediately.
    local cmd = "extensions.load('underscoreIgnition')"
    local ok, err = pcall(function()
        vehicle:queueLuaCommand(cmd)
    end)

    if not ok then
        log("E", "underscoreOut", ("Failed to queue load for vehicle %d: %s"):format(id, tostring(err)))
    else
        log("I", "underscoreOut", ("Queued underscoreIgnition into player vehicle %d"):format(id))
    end
end


-- ── Extension lifecycle hooks ───────────────────────────────────────────────

function M.onExtensionLoaded()
    log("I", "underscoreOut", "onExtensionLoaded")

    -- Open UDP socket via LuaSocket (bundled with BeamNG)
    local ok, socket = pcall(require, "socket")
    if not ok or not socket then
        log("E", "underscoreOut", ("LuaSocket require failed: %s"):format(tostring(socket)))
        return false
    end

    local sockOk, sockErr = pcall(function()
        udp = socket.udp()
        udp:settimeout(0)  -- non-blocking sends
    end)

    if not sockOk or not udp then
        log("E", "underscoreOut", ("socket.udp() setup failed: %s"):format(tostring(sockErr)))
        udp = nil
        return false
    end

    running = true
    currentVehicleId = -1
    lastLevel = -1
    elapsed = 0

    log("I", "underscoreOut", ("ignition broadcast -> %s:%d"):format(HOST, PORT))
end


function M.onUpdate(dtReal)
    if not running then return end

    local dt = dtReal or 0
    elapsed = elapsed + dt

    -- Check for player vehicle changes (only acts when vehicle ID changes)
    ensureVehicleExtension()

    -- External UDP heartbeat: send last known level every ~1 second so the
    -- listener knows we're alive even if ignition hasn't changed.
    if elapsed >= HEARTBEAT_INTERVAL then
        elapsed = elapsed - HEARTBEAT_INTERVAL  -- preserve remainder to avoid drift
        broadcast(lastLevel)
    end
end


function M.onExtensionUnloaded()
    running = false

    if udp then
        pcall(function() udp:close() end)
        udp = nil
    end

    currentVehicleId = -1
    log("I", "underscoreOut", "stopped")
end


-- ── Diagnostic status (callable from console: extensions.underscoreOut.status()) ────
function M.status()
    return {
        running = running,
        socketOpen = udp ~= nil,
        currentVehicleId = currentVehicleId,
        lastLevel = lastLevel,
        peer = ("%s:%d"):format(HOST, PORT),
    }
end

return M
