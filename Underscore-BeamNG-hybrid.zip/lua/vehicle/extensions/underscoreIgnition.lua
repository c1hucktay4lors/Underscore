-- Underscore-BeamNG - Vehicle side (VLUA)
--
-- This extension runs inside each vehicle's Vehicle Lua VM. It reads the
-- ignition level directly from electrics.values.ignitionLevel — this data
-- lives in VLUA and is NOT accessible from Game Engine Lua.
--
-- Loaded automatically for all vehicles when mod is enabled, or explicitly via:
--   be:getPlayerVehicle(0):queueLuaCommand("extensions.load('underscoreIgnition')")

local M = {}

local POLL_INTERVAL = 0.05    -- poll at ~20 Hz (fast enough to catch cranking)

local pollTimer = 0           -- accumulator for polling interval
local lastLevel = -1          -- last level we sent to GE


-- ── Send ignition level back to GE Lua via VM bridge ────────────────────────
local function sendToGE(level)
    if not obj or type(obj.queueGameEngineLua) ~= "function" then return end

    local cmd = string.format("extensions.underscoreOut.receiveIgnition(%d)", level)
    local ok, err = pcall(function()
        obj:queueGameEngineLua(cmd)
    end)

    if not ok then
        log("E", "underscoreIgnition", ("Failed to queue GE update: %s"):format(tostring(err)))
    end
end


-- ── Sample ignition level from electrics ────────────────────────────────────
local function sample()
    -- Direct access in VLUA context — this is where electrics.values lives.
    local level = nil

    if electrics and electrics.values then
        level = electrics.values.ignitionLevel
    end

    if type(level) ~= "number" then return end

    -- Round to nearest int (BeamNG may send fractional values during transitions)
    level = math.floor(level + 0.5)
    if level < 0 or level > 3 then return end

    -- Send on change only — GE handles external heartbeat independently
    if level ~= lastLevel then
        lastLevel = level
        log("I", "underscoreIgnition", ("ignitionLevel=%d"):format(level))
        sendToGE(level)
    end
end


-- ── Extension lifecycle hooks ───────────────────────────────────────────────

function M.onExtensionLoaded()
    pollTimer = 0
    lastLevel = -1

    log("I", "underscoreIgnition", ("loaded in vehicle %s"):format(tostring(obj and obj.name or "?")))
end


-- Called automatically every frame by BeamNG's vehicle extension system.
function M.updateGFX(dt)
    dt = dt or 0
    pollTimer = pollTimer + dt

    if pollTimer >= POLL_INTERVAL then
        pollTimer = pollTimer - POLL_INTERVAL  -- preserve remainder to avoid drift
        sample()
    end
end


-- Reset on vehicle reset/restart (e.g., respawn, scene reload)
function M.onReset()
    pollTimer = 0
    lastLevel = -1
end

return M
